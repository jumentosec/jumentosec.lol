<page>
  title: Home
</page>

<script setup lang="ts">
  import HelloSection from '@/sections/HelloSection.vue'
</script>

<template>
  <main class="mx-auto w-full max-w-text">
    <HelloSection />
  </main>
</template>

<page>
  title: Works
</page>

<script setup lang="ts">
  import WorksSection from '@/sections/WorksSection.vue'
</script>

<template>
  <!-- Classes `mx-auto`, `w-full` and `max-w-text` not applied so that tables can span full width. -->
  <main>
    <WorksSection />
  </main>
</template>

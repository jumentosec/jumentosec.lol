export default {
  title: 'Dhruv Bhanushali',
  description:
    'Hi! I am Dhruv Bhanushali, a software engineer who writes well-documented code, builds accessible interfaces and ships delightful apps.',
  author: 'Dhruv Bhanushali',
  resumeUrl:
    'https://raw.githubusercontent.com/dhruvkb/reschume/main/sample_data/dhruvkb.json',
}

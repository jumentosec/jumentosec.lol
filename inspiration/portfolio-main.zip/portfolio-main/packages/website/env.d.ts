/// <reference types="vite/client" />
/// <reference types="iles" />
/// <reference types="unplugin-icons/types/vue" />

<a href="https://dhruvkb.github.io">
  <img src="readme_assets/cover.jpeg" alt="A picture of me" width="100%"/>
</a>

<h1 align="center">
  Dhruv Bhanushali
</h1>

## Portfolio

Hello! I am [Dhruv Bhanushali](https://dhruvkb.dev/), an engineering graduate
from the Indian Institute of Technology, Roorkee. I develop software, both as a
hobby and as a profession.

This is my portfolio, my tiny personal slice of the Internet.

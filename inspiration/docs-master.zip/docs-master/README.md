# Blink Shell Documentation

Build using [Nextra 2.0](https://github.com/shuding/nextra).

- [Blink Shell](https://github.com/blinksh/blink)
- [AppStore](http://itunes.apple.com/app/id1156707581)
- [Community Edition](https://community.blink.sh)

## Social 

- [Discord](https://discord.gg/ZTtMfvK)
- [Twitter](https://twitter.com/blinkshell)
- [Reddit](https://reddit.com/r/BlinkShell)
- [GH Discussions](http://github.com/blinksh/blink/discussions)
